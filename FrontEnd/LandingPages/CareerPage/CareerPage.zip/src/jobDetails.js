import img02 from "./images/img--02.png";

export default function StageOne() {
  return (
    <>
      <JobDetails />
    </>
  )
}


export function JobDetails({ jobid }) {



  

  return (
    <>
      
    </>
  );
}